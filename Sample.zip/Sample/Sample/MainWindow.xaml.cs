﻿using System.Windows;
using System.Drawing;
using System.Windows.Forms.DataVisualization.Charting;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Sample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ObservableCollection<Person> persons = new ObservableCollection<Person>();
            persons.Add(new Person() { Name="Dr Bake", Rank= "1", Score="500", Average ="1"});
            persons.Add(new Person() { Name = "Clemens", Rank = "2", Score = "400", Average = "2" });
            persons.Add(new Person() { Name = "Raman", Rank = "3", Score = "300", Average = "3" });
            persons.Add(new Person() { Name = "Peter", Rank = "4", Score = "200", Average = "4" });
            persons.Add(new Person() { Name = "Tiny Giant", Rank = "5", Score = "100", Average = "5" });

            sampleGrid.ItemsSource = persons;
        }


        public void PrepareChat()
        {
            //var xValues = new[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
            //var yValues = new[] { 4, 6, 8, 5, 4, 4, 6, 8, 5, 4, 4, 6, 8, 5, 4, 4, 6, 8, 5, 4 };

            //chart1.Size = new System.Drawing.Size(400, 250);
            
            //var chartArea = new ChartArea();
            //chartArea.AxisX.MajorGrid.LineColor = Color.LightGray;
            //chartArea.AxisX.Title = "X axis";
            //chartArea.AxisY.MajorGrid.LineColor = Color.LightGray;
            //chart1.ChartAreas.Add(chartArea);

            //Series series = new Series();
            //series.Name = "Series1";
            //series.ChartType = SeriesChartType.Radar;

            //series.XValueType = ChartValueType.Int32;
            //chart1.Series.Add(series);

            //chart1.Series["Series1"].Points.DataBindXY(xValues,yValues);
            
            //chart1.Invalidate();

        }


        private void GetAllChilds(DependencyObject parent,ref List<DependencyObject> allChildrens)
        {
            var children = LogicalTreeHelper.GetChildren(parent);
           foreach (var child in children)
            {
                var dp = child as DependencyObject;
                allChildrens.Add(dp);
                GetAllChilds(dp, ref allChildrens);
            }

        }


    }
}


