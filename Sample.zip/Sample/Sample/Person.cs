﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample
{
    public class Person 
    {

        public string Name { get; set; }
        public string Rank { get; set; }
        public string Score { get; set; }
        public string Average { get; set; }

    }
}
